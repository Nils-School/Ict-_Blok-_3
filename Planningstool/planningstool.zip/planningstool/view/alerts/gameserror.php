<div class="alert alert-danger">
    <strong>Fout!</strong> Er zijn al meer dan 10 verschillende games gepland.
  </div>