<div class="alert alert-danger">
    <strong>Fout!</strong> Deze tijd is al geselecteerd, selecteer een andere tijd alstublieft.
  </div>