<div class="alert alert-success">
  <strong>Succes!</strong> De game is ge-edit.
</div>