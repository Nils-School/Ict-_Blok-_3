<div class="alert alert-danger">
  <strong>Fout!</strong> Niet elk vak is ingevuld.
</div>