<div class="alert alert-success">
  <strong>Succes!</strong> De game is gepland.
</div>